window.LOCAL_CONFIG = {
  // API_HOME: 'http://10.20.37.227:8088/', // 粉丝端接口默认
  // IFS_API_HOME: 'http://10.20.37.228:80/', // 领投保接口
  // QUOTE_HOME: 'http://10.20.18.174:9018/', // 行情接口
  // TENANT_KEY: '0c7a4f76884b464782caa9eca8dc7a0e', // 测试环境tenantKey
  // COMPANY_ID: '20045',
  // STATIC_SITE: 'http://211.156.202.8/h5-fans-zy/', // 观点分享地址
  // APP_DOWNLOAD_LINK: 'https://mall.cnpsec.com:8088/share/download.html', // APP 下载链接

  API_HOME: 'https://hstgfans.cnpsec.com:80/', // 粉丝端接口默认
  IFS_API_HOME: 'https://hstgfans.cnpsec.com:80/', // 领投保接口
  QUOTE_HOME: 'https://hstgfans.cnpsec.com:80/', // 行情接口
  TENANT_KEY: 'e40cefdf9c464a3fb7b847849874ef', // 测试环境tenantKey
  COMPANY_ID: '20045',
  STATIC_SITE: 'https://hstgfans.cnpsec.com:80/h5-fans-share-zy/', // 观点分享地址
  APP_DOWNLOAD_LINK: 'https://mall.cnpsec.com:8088/share/download.html', // APP 下载链接

  IS_OPEN_VCONSOLE: true,
};

