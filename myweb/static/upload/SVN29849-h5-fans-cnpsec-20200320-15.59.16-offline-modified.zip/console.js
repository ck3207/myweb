// 移动端调试工具
if (window.LOCAL_CONFIG.IS_OPEN_VCONSOLE) {
  document.write('<script src="./vconsole.min.js"' + '>' + '<' + '/' + 'script>');
}
